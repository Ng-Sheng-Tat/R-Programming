Introduction
============

R as a programming language:

* Start with the basic building blocks of R like data types and low-level details
* Writing and formulating R scripts: control structures and functions

Packages for visualization and machine learning will be covered in other sections of the R concentration.