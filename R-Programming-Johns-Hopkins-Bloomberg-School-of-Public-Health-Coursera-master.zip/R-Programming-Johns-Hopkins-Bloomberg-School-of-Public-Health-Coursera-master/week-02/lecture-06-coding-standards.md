Coding Standards
================

1. Use a text editor and save your file with the ASCII character set.
2. Indent your code
3. Limit the width of your code (80 columns?)
4. Limit the length of individual functions (one basic activity)