coursera-r-programming
======================

Notes from the R programming Coursera course
